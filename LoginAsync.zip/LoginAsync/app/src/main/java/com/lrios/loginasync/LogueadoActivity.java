package com.lrios.loginasync;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class LogueadoActivity extends AppCompatActivity {

    TextView tvUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logueado);

        tvUser = (TextView) findViewById(R.id.la_tv_usuario);
        tvUser.setText(getIntent().getStringExtra("user"));
    }
}
