package com.lrios.loginasync;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edtUser,edtPass;
    Button btnLogin;
    ArrayList<String> usuarios = new ArrayList<>();
    ArrayList<String> claves = new ArrayList<>();
    String user, clave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUser = (EditText) findViewById(R.id.ma_edt_user);
        edtPass = (EditText) findViewById(R.id.ma_edt_pass);
        btnLogin = (Button) findViewById(R.id.ma_btn_login);

        //Llenamos el ArrayList con usuarios
        usuarios.add("luis16");
        claves.add("1234");
        usuarios.add("abcdef");
        claves.add("12345");

    }

    //Método del botón
    public void loguearse(View v){
        //Instancio una tarea asincronica de login y la ejecuto
        asyncLogin loguenadose = new asyncLogin();
        loguenadose.execute();

    }

    //Metodo para validar los datos para saber si me logueo
    public boolean validar(String usuario, String contra){

        boolean todobien = false;
        //Validar que los datos estén correctos recorriendo el A.L.
        for (int i=0;i<usuarios.size();i++){
            if (usuarios.get(i).equals(usuario) && claves.get(i).equals(contra)){

                todobien = true;
                break;
            } else{
                //Toast.makeText(MainActivity.this,"Error de usuario o contraseña!", Toast.LENGTH_SHORT).show();
                todobien = false;
            }
        }

        return todobien;
    }

    //Clase del login asincronico
    public class asyncLogin extends AsyncTask<String, Void, String>{
        @Override
        protected void onPreExecute() {
            //Preparamos los objetos trayendo los datos
            user = edtUser.getText().toString();
            clave = edtPass.getText().toString();

            //Deshabilitamos el botón.
            btnLogin.setEnabled(false);

            Toast.makeText(MainActivity.this, "Validando datos... ",Toast.LENGTH_LONG).show();
        }

        @Override
        protected String doInBackground(String... strings) {
            //Valido el usuario y contraseña
            if (validar(user, clave)){
                //Si es correcto espero 5 segundos
                try {
                    Thread.sleep(5000);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                //Mando a la otra actividad
                Intent obj_intent = new Intent(MainActivity.this,LogueadoActivity.class);
                obj_intent.putExtra("user",user);
                startActivity(obj_intent);
            } else {

                //Pero si no es correcto espero 10 segundos y mando un Toast
                try {
                    Thread.sleep(10000);
                } catch (Exception ex){
                    ex.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            //Aquí habilito el botón por si es fake la vuelta esa
            btnLogin.setEnabled(true);
            if (validar(user, clave)){
                Toast.makeText(MainActivity.this,"Datos correctos!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this,"Error de usuario o contraseña", Toast.LENGTH_SHORT).show();
            }
        }


    }
}
