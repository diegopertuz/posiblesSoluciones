package com.lrios.soat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Creando variables de los elementos a usar
    RadioButton rbCarro, rbMoto, rbAcciSi,rbAcciNo, rbInfraSi, rbInfraNo;
    EditText etNumAcci;
    CheckBox chkAcepto;
    Button btnCalcular;

    //Creando objeto SOAT
    Soat soat;

    //Creando variables a enviar
    int vehiculo;
    double numAcci;
    boolean infraccion, accidente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Buscar elementos de la vista y asignarlos a la variable
        rbCarro = findViewById(R.id.rbCarro);
        rbMoto = findViewById(R.id.rbMoto);
        rbAcciSi = findViewById(R.id.rbAcciSi);
        rbAcciNo = findViewById(R.id.rbInfraSi);
        rbInfraSi = findViewById(R.id.rbInfraSi);
        rbInfraNo = findViewById(R.id.rbInfraNo);
        etNumAcci = findViewById(R.id.etNumAcci);
        etNumAcci.setEnabled(true); //Por defecto que no deje escribir
        chkAcepto = findViewById(R.id.chkAcepto);
        btnCalcular = findViewById(R.id.btnCalcular);

        //Instanciando objeto
        soat = new Soat();

    }

    public void calcularSoat(View view){
        //Condicional para saber cuál es el vehiculo escogido
        if (rbCarro.isChecked()){
            vehiculo = 1;
        } else  if (rbMoto.isChecked()){
            vehiculo = 2;
        } else {
            Toast.makeText(this,"Alto error, por favor elegir un vehiculo",Toast.LENGTH_SHORT).show();
        }

        //Condicional de Accidentes
        if (rbAcciSi.isChecked()){
            etNumAcci.setEnabled(true);
            accidente = true;
        } else  if (rbAcciNo.isChecked()){
            accidente = false;
            etNumAcci.setEnabled(false);
        } else  {
            Toast.makeText(this,"Alto error, por favor elegir si tuvo accidentes",Toast.LENGTH_SHORT).show();
        }

        if (etNumAcci.getText().equals("")){
            numAcci = 0;
        } else {
            numAcci = Double.parseDouble(etNumAcci.getText().toString());
        }

        //Condicional de Infracciones
        if (rbInfraSi.isChecked()){
            infraccion = true;
        } else  if (rbInfraNo.isChecked()){
            infraccion = false;
            etNumAcci.setEnabled(false);
        } else  {
            Toast.makeText(this,"Alto error, por favor elegir si tuvo accidentes",Toast.LENGTH_SHORT).show();
        }
        String valorSoat = String.valueOf(soat.calcular(vehiculo,numAcci,infraccion));

        Toast.makeText(this,"Valor del SOAT: $"+valorSoat,Toast.LENGTH_LONG).show();

    }

    public void AceptarTerminos(View view){
        if (chkAcepto.isChecked()){
            btnCalcular.setEnabled(true);
        } else {
            btnCalcular.setEnabled(false);
        }

    }

}
