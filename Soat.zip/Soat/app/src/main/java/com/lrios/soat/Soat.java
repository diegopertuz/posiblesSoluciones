package com.lrios.soat;

public class Soat {

    public Soat(){


    }

    public double calcular(int tipoVehiculo, double cantAccidente, boolean infraccion){

        double total=0;
        double subtotal=0, cargoAccidente, cargoInfraccion;

        switch(tipoVehiculo){
            case 1: //Carro
                subtotal=280000;
                break;
            case 2: //Moto
                subtotal=480100;
                break;
        }

        if (cantAccidente<=10) {
            cargoAccidente=subtotal*(cantAccidente/100);
        } else {
            cargoAccidente = subtotal;
        }

        if (infraccion) {
            cargoInfraccion = subtotal*0.45;
        } else {
            cargoInfraccion = 0;
        }

        total = subtotal+cargoAccidente+cargoInfraccion;

        return total;
    }

}

